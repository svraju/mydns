package dns.discover.service.repository;

import dns.discover.service.entity.Account;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
//import org.springframework.stereotype.Repository;

/**
 * User Repository
 */
//@Repository 
public interface UserRepository extends PagingAndSortingRepository<Account, Long>, JpaRepository<Account, Long> {
	
}