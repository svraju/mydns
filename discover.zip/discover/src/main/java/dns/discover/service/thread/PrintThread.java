package dns.discover.service.thread;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class PrintThread extends Thread{

    /**
     * Run method printing out the names of running threads.
     */
    @Override
    public void run() {

        System.out.println(getName() + " is running");
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
                e.printStackTrace();
        }
        System.out.println(getName() + " is running");
    }

}
